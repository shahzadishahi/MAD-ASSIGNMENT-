import React, { useState } from "react";
import { 
  View, Text, Button, TextInput, FlatList, 
  TouchableOpacity, StyleSheet, ScrollView, Image 
} from "react-native";
import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { PieChart } from "react-native-svg-charts";

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const sampleTransactions = [
  { id: "1", type: "Expense", category: "Food", amount: 20, image: "https://cdn-icons-png.flaticon.com/512/1046/1046784.png" },
  { id: "2", type: "Income", category: "Salary", amount: 500, image: "https://cdn-icons-png.flaticon.com/512/2331/2331944.png" },
  { id: "3", type: "Expense", category: "Transport", amount: 15, image: "https://cdn-icons-png.flaticon.com/512/1048/1048950.png" },
];

const DashboardScreen = ({ navigation }) => {
  const totalIncome = sampleTransactions
    .filter((t) => t.type === "Income")
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = sampleTransactions
    .filter((t) => t.type === "Expense")
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: "https://cdn-icons-png.flaticon.com/512/2916/2916065.png" }} style={styles.dashboardImage} />
      <Text style={styles.title}>Dashboard</Text>
      <Text style={styles.statText}>💰 Income: ${totalIncome}</Text>
      <Text style={styles.statText}>💸 Expense: ${totalExpense}</Text>
      <Text style={styles.statText}>💵 Balance: ${totalIncome - totalExpense}</Text>

      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate("Transactions")}>
        <Text style={styles.buttonText}>📜 View Transactions</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate("AddExpense")}>
        <Text style={styles.buttonText}>➕ Add Expense</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const AddExpenseScreen = ({ navigation }) => {
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("");

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Add Expense</Text>
      <TextInput 
        placeholder="Amount"
        keyboardType="numeric"
        style={styles.input}
        value={amount}
        onChangeText={setAmount}
      />
      <TextInput 
        placeholder="Category"
        style={styles.input}
        value={category}
        onChangeText={setCategory}
      />
      <TouchableOpacity style={styles.button} onPress={() => { alert("Expense Added!"); navigation.goBack(); }}>
        <Text style={styles.buttonText}>💾 Save</Text>
      </TouchableOpacity>
    </View>
  );
};

const TransactionsScreen = () => (
  <View style={styles.container}>
    <Text style={styles.title}>Transactions</Text>
    <FlatList
      data={sampleTransactions}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <View style={styles.transactionItem}>
          <Image source={{ uri: item.image }} style={styles.transactionImage} />
          <View>
            <Text style={styles.transactionText}>{item.category}: ${item.amount}</Text>
            <Text style={{ color: item.type === "Income" ? "green" : "red" }}>{item.type}</Text>
          </View>
        </View>
      )}
    />
  </View>
);

const ReportsScreen = () => {
  const data = [
    { key: 1, amount: 20, svg: { fill: "#FF6384" } },
    { key: 2, amount: 500, svg: { fill: "#36A2EB" } },
    { key: 3, amount: 15, svg: { fill: "#FFCE56" } },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Reports & Analytics</Text>
      <PieChart style={{ height: 200, width: 200 }} data={data} />
    </View>
  );
};

const BudgetScreen = () => {
  const [budget, setBudget] = useState("1000");

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Set Monthly Budget</Text>
      <TextInput 
        placeholder="Enter Budget"
        keyboardType="numeric"
        style={styles.input}
        value={budget}
        onChangeText={setBudget}
      />
      <TouchableOpacity style={styles.button} onPress={() => alert("Budget Updated!")}>
        <Text style={styles.buttonText}>💾 Save</Text>
      </TouchableOpacity>
    </View>
  );
};

const ProfileScreen = () => (
  <View style={styles.container}>
    <Text style={styles.title}>Profile & Theme</Text>
    <TouchableOpacity style={styles.button} onPress={() => alert("Theme Changed!")}>
      <Text style={styles.buttonText}>🎨 Change Theme</Text>
    </TouchableOpacity>
  </View>
);

const HomeTabs = () => (
  <Tab.Navigator>
    <Tab.Screen name="Dashboard" component={DashboardScreen} />
    <Tab.Screen name="Transactions" component={TransactionsScreen} />
    <Tab.Screen name="Reports" component={ReportsScreen} />
    <Tab.Screen name="Profile" component={ProfileScreen} />
  </Tab.Navigator>
);

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="HomeTabs" component={HomeTabs} options={{ headerShown: false }} />
        <Stack.Screen name="AddExpense" component={AddExpenseScreen} />
        <Stack.Screen name="Budget" component={BudgetScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#F8F9FA" },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 10, textAlign: "center" },
  statText: { fontSize: 18, marginVertical: 5, textAlign: "center" },
  input: { borderWidth: 1, borderRadius: 5, padding: 10, marginVertical: 10, backgroundColor: "#FFF" },
  transactionItem: { flexDirection: "row", padding: 10, borderBottomWidth: 1, alignItems: "center" },
  transactionImage: { width: 40, height: 40, marginRight: 10 },
  transactionText: { fontSize: 16 },
  button: { backgroundColor: "#007AFF", padding: 10, borderRadius: 5, alignItems: "center", marginVertical: 10 },
  buttonText: { color: "white", fontWeight: "bold" },
  dashboardImage: { width: 100, height: 100, alignSelf: "center", marginBottom: 10 }
});
