import React, { useState } from "react";
import { 
  View, Text, TextInput, FlatList, Image, 
  TouchableOpacity, StyleSheet, ScrollView 
} from "react-native";
import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Sample Data
const restaurants = [
  { id: "1", name: "Pizza Palace", rating: 4.8, image: "https://cdn-icons-png.flaticon.com/512/1046/1046784.png" },
  { id: "2", name: "Sushi Express", rating: 4.6, image: "https://cdn-icons-png.flaticon.com/512/2276/2276931.png" },
  { id: "3", name: "Burger Town", rating: 4.7, image: "https://cdn-icons-png.flaticon.com/512/3075/3075977.png" },
];

// Home Screen
const HomeScreen = ({ navigation }) => (
  <ScrollView style={styles.container}>
    <Text style={styles.title}>🍽️ Restaurants</Text>
    <TextInput style={styles.searchInput} placeholder="🔍 Search restaurants..." />
    <FlatList
      data={restaurants}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <TouchableOpacity style={styles.card} onPress={() => navigation.navigate("RestaurantDetails", { restaurant: item })}>
          <Image source={{ uri: item.image }} style={styles.image} />
          <Text style={styles.cardTitle}>{item.name}</Text>
          <Text style={styles.rating}>⭐ {item.rating}</Text>
        </TouchableOpacity>
      )}
    />
  </ScrollView>
);

// Restaurant Details Screen (FIXED)
const RestaurantDetailsScreen = ({ route, navigation }) => {
  const { restaurant } = route.params;
  return (
    <View style={styles.container}>
      <Image source={{ uri: restaurant.image }} style={styles.bigImage} />
      <Text style={styles.title}>{restaurant.name}</Text>
      <Text style={styles.rating}>⭐ {restaurant.rating} / 5</Text>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate("Orders")}>
        <Text style={styles.buttonText}>🛒 Order Now</Text>
      </TouchableOpacity>
    </View>
  );
};

// Orders Screen
const OrdersScreen = () => (
  <View style={styles.container}>
    <Text style={styles.title}>📦 My Orders</Text>
    <Text style={styles.subText}>🍔 Burger - Delivered</Text>
    <Text style={styles.subText}>🍕 Pizza - In Progress</Text>
  </View>
);

// Favorites Screen
const FavoritesScreen = () => (
  <View style={styles.container}>
    <Text style={styles.title}>❤️ Favorite Restaurants</Text>
    <Text style={styles.subText}>🍣 Sushi Express</Text>
    <Text style={styles.subText}>🍕 Pizza Palace</Text>
  </View>
);

// Offers Screen
const OffersScreen = () => (
  <View style={styles.container}>
    <Text style={styles.title}>🎉 Special Offers</Text>
    <Text style={styles.subText}>🔥 20% OFF on Sushi Express</Text>
    <Text style={styles.subText}>🔥 Buy 1 Get 1 Free - Burger Town</Text>
  </View>
);

// Profile & Order History Screen
const ProfileScreen = () => (
  <View style={styles.container}>
    <Text style={styles.title}>👤 Profile & Order History</Text>
    <Text style={styles.subText}>Recent Order: 🍔 Burger - $10</Text>
    <Text style={styles.subText}>Recent Order: 🍕 Pizza - $12</Text>
  </View>
);

// Bottom Tab Navigation
const HomeTabs = () => (
  <Tab.Navigator screenOptions={{ headerShown: false }}>
    <Tab.Screen name="Home" component={HomeScreen} />
    <Tab.Screen name="Orders" component={OrdersScreen} />
    <Tab.Screen name="Favorites" component={FavoritesScreen} />
    <Tab.Screen name="Offers" component={OffersScreen} />
    <Tab.Screen name="Profile" component={ProfileScreen} />
  </Tab.Navigator>
);

// Main App
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="HomeTabs" component={HomeTabs} />
        <Stack.Screen name="RestaurantDetails" component={RestaurantDetailsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#F8F9FA", alignItems: "center" },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 10, color: "#333" },
  subText: { fontSize: 18, marginBottom: 5, color: "#555" },
  searchInput: { width: "100%", padding: 10, marginBottom: 10, borderRadius: 5, backgroundColor: "#FFF", borderWidth: 1 },
  card: { backgroundColor: "#FFF", padding: 10, marginBottom: 10, borderRadius: 10, width: "100%", alignItems: "center", shadowColor: "#000", shadowOpacity: 0.2, shadowRadius: 5 },
  image: { width: 80, height: 80, borderRadius: 10 },
  bigImage: { width: 150, height: 150, marginBottom: 10 },
  cardTitle: { fontSize: 18, fontWeight: "bold", marginVertical: 5, color: "#333" },
  rating: { color: "green", fontSize: 16 },
  button: { backgroundColor: "#FF5733", padding: 10, borderRadius: 5, alignItems: "center", marginVertical: 10, width: "80%" },
  buttonText: { color: "white", fontWeight: "bold", fontSize: 16 },
});
