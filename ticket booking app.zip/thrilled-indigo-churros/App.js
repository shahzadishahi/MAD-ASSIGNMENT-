import React, { useState } from "react";
import { 
  View, Text, Button, TextInput, FlatList, 
  TouchableOpacity, StyleSheet, Image 
} from "react-native";
import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Sample data for events, movies, and flights
const events = [
  { id: "1", name: "Movie: Avengers", image: "https://m.media-amazon.com/images/I/81ExhpBEbHL._AC_SY679_.jpg" },
  { id: "2", name: "Concert: Coldplay", image: "https://images.unsplash.com/photo-1740471230719-60fc0bfd42e1?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHw1fHx8ZW58MHx8fHx8" },
  { id: "3", name: "Flight: ISB to Dubai", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTXRAy6k-QSMzI7SJaqUt7amfFHOprsraWSw&s" }
];

// Home Screen
const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <FlatList
        data={events}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate("BookingDetails", { item })} style={styles.card}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <Text style={styles.listItem}>{item.name}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

// Search & Filter Screen
const SearchScreen = () => {
  const [query, setQuery] = useState("");

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Search events..."
        style={styles.input}
        value={query}
        onChangeText={setQuery}
      />
      <Button title="Search" onPress={() => alert(`Searching for: ${query}`)} />
    </View>
  );
};

// Booking Details Screen
const BookingDetailsScreen = ({ route, navigation }) => (
  <View style={styles.container}>
    <Text style={styles.title}>Booking for: {route.params.item.name}</Text>
    <Image source={{ uri: route.params.item.image }} style={styles.largeImage} />
    <Button title="Select Seats" onPress={() => alert("Seats Selected!")} />
    <Button title="Proceed to Payment" onPress={() => navigation.navigate("Payment")} />
  </View>
);

// Payment Screen
const PaymentScreen = ({ navigation }) => (
  <View style={styles.container}>
    <Text style={styles.title}>Choose Payment Method</Text>
    <Button title="Apply Discount" onPress={() => alert("Discount Applied!")} />
    <Button title="Pay Now" onPress={() => {
      alert("Payment Successful!");
      navigation.navigate("MyBookings");
    }} />
  </View>
);

// My Bookings Screen
const MyBookingsScreen = () => (
  <View style={styles.container}>
    <Text style={styles.title}>Upcoming & Past Bookings</Text>
  </View>
);

// Profile & Settings Screen
const ProfileScreen = () => (
  <View style={styles.container}>
    <Image source={{ uri: "https://images.unsplash.com/photo-1740564014446-f07ea2da269c?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwxMTJ8fHxlbnwwfHx8fHw%3D" }} style={styles.profileImage} />
    <Text style={styles.title}>User Profile</Text>
    <Text>Payment History: No transactions yet</Text>
    <Button title="Edit Profile" onPress={() => alert("Edit Profile Clicked")} />
  </View>
);

// Bottom Tab Navigator
const HomeTabs = () => (
  <Tab.Navigator>
    <Tab.Screen name="Home" component={HomeScreen} />
    <Tab.Screen name="Search" component={SearchScreen} />
    <Tab.Screen name="Bookings" component={MyBookingsScreen} />
    <Tab.Screen name="Profile" component={ProfileScreen} />
  </Tab.Navigator>
);

// Main App
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="HomeTabs" component={HomeTabs} options={{ headerShown: false }} />
        <Stack.Screen name="BookingDetails" component={BookingDetailsScreen} />
        <Stack.Screen name="Payment" component={PaymentScreen} />
        <Stack.Screen name="MyBookings" component={MyBookingsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center", padding: 20, backgroundColor: "#F0F8FF" },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 20, color: "#333" },
  input: { width: "100%", padding: 10, marginVertical: 10, borderWidth: 1, borderRadius: 5, backgroundColor: "#fff" },
  listItem: { fontSize: 18, padding: 10, color: "#444" },
  card: { backgroundColor: "#fff", padding: 15, marginVertical: 5, borderRadius: 10, alignItems: "center", shadowColor: "#000", shadowOpacity: 0.1, shadowOffset: { width: 0, height: 2 }, elevation: 3 },
  image: { width: 120, height: 120, borderRadius: 10, marginBottom: 10 },
  largeImage: { width: 300, height: 200, borderRadius: 10, marginBottom: 20 },
  profileImage: { width: 100, height: 100, borderRadius: 50, marginBottom: 10 },
});
